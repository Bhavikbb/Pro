package com.infosys.project.order.dto;

public class newPlaceOrder {
 private Integer buyerid;
 private String address;
public Integer getBuyerid() {
	return buyerid;
}
public void setBuyerid(Integer buyerid) {
	this.buyerid = buyerid;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
 
 
}
