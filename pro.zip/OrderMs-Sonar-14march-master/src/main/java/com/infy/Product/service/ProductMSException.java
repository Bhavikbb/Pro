package com.infy.Product.service;

public class ProductMSException extends Exception {

	public ProductMSException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
