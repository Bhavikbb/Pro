package com.infy.ProductMS;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ProductMsApplicationTests {

	@Test
	public void contextLoads() {
	}

}
